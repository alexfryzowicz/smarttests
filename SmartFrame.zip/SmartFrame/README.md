
# Task 1: Compare SmartFrames 

SMARTFRAME 1:
you can zoom in twice 
can zoom on fullscreen 
copy link on share options
can copy script with embed option

SMARTFRAME 2:
watermark
redirect to SmartfFrame page


# Introduction

Here we have an automation test pack

# Getting started

1. Run `npm ci`
2. Install Cypress: `npm install cypress@9.4` 
3. Run feature tests `npx cypress open`


## Folder structure

1. test scenario 1
Please check path: /cypress/integration/BDD/testScenario1/testScenario1.spec.js 
and feature file for this: /cypress/integration/BDD/testScenario1.feature

2. test scenario 2
Please check path: /cypress/integration/BDD/testScenario1/testScenario2.spec.js 
and feature file for this: /cypress/integration/BDD/testScenario2.feature


