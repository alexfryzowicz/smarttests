class SmartFramePage {


    get entryContent() {
        return cy.get('.post-body entry-content');
    }
    get captionText() {
        return cy.get('.caption-text');
    }
    get embedButton() {
        return cy.get('.smartframe-embed');
    }
}

export default new SmartFramePage();