import { Given, And Then, When } from 'cypress-cucumber-preprocessor/steps';
import SmartFramePage from '../../../support/SmartFramePage';


Given('Open SmartFrame 1', () => {
   cy.visit("p/e.html");
});

When('Mouse over the SmartFrame, Check if the caption is correctly displayed', () => {
    SmartFramePage.entryContent.scrollTo('center');
    SmartFramePage.captionText.should("be.visible");
 });

 And('Click on the icon in the top-left-hand corner of the SmartFrame', () => {
    SmartFramePage.embedButton.click(); 
 });

 Then('Check if the layer opens', () => {
    getIframeBody().find('button').should('have.text', 'COPY').should("be.visible");
 });
