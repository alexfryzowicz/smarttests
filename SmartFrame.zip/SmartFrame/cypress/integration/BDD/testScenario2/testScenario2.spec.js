import { Given, And Then, When } from 'cypress-cucumber-preprocessor/steps';
import SmartFramePage from '../../../support/SmartFramePage';


Given('Mouse over the SmartFrame', () => {
   cy.visit("p/e.html");
   SmartFramePage.entryContent.scrollTo('center');
});

When('Check if the Share button is displayed correctly', () => {
    getIframeBody().find('button').should('have.text', 'SHARE').should("be.visible");
    SmartFramePage.entryContent.scrollTo('center');
 });

 And('Click on the icon in the top-left-hand corner of the SmartFrame', () => {
    getIframeBody()
        .find('button')
        .should('have.text', 'SE')
        .invoke('removeAttr', 'target')
        .click();
 });

 Then('Check if the redirect works', () => {
    cy.url({ timeout: 20000 }).should("include", "https://smartframe.io/");
 });
